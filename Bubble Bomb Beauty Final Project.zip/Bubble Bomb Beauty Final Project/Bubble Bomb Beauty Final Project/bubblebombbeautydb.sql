-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 22, 2021 at 02:51 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bubblebombbeauty1`
--
CREATE DATABASE IF NOT EXISTS `bubblebombbeauty1` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `bubblebombbeauty1`;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `OID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ORDER_NO` varchar(45) NOT NULL DEFAULT '',
  `ORDER_DATE` date NOT NULL DEFAULT '0000-00-00',
  `UID` int(10) unsigned NOT NULL DEFAULT '0',
  `TOTAL_AMT` double(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`OID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE IF NOT EXISTS `order_details` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `OID` int(10) unsigned NOT NULL DEFAULT '0',
  `PID` int(10) unsigned NOT NULL DEFAULT '0',
  `PNAME` varchar(45) NOT NULL DEFAULT '',
  `PRICE` double(10,2) NOT NULL DEFAULT '0.00',
  `QTY` int(10) unsigned NOT NULL DEFAULT '0',
  `TOTAL` double(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `PID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PRODUCT` varchar(45) NOT NULL DEFAULT '',
  `PRICE` double(10,2) NOT NULL DEFAULT '0.00',
  `IMAGE` varchar(100) NOT NULL DEFAULT '',
  `DESCRIPTION` text,
  PRIMARY KEY (`PID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `products`
--



INSERT INTO `products` (`PID`, `PRODUCT`, `PRICE`, `IMAGE`, `DESCRIPTION`) VALUES
(1, 'Whats up doc', 20.00, '1.jpg', 'Enjoy this fabulous moisturizer fused with carrot juice, carrot seeds and carrot extract.'),
(2, 'Honey I washed the kids', 15.00, '2.jpg', '"Nothing feels better than a nice clean shower! Enjoy our luxorious shower gel. Fused with lavender and jasmine.'),
(3, 'Make Lemonade', 18.99, '3.jpg', 'The lemon in the water will normalize the skin and decrease the oil secretion. It will energize your body for the whole day. Combats odor from the body. Regular activity causes sweat in our body which attracts several germs and bacteria.'),
(4, 'Sleeping beauty', 10.99, '4.jpg', 'The lemon in the water will normalize the skin and decrease the oil secretion. It will energize your body for the whole day. Combats odor from the body. Regular activity causes sweat in our body which attracts several germs and bacteria.'),
(5, "Siren's Salt", 10.99, '5.jpg', 'Lift away dirt and dullness with a daily scrub made with real strawberries and smoothing sugar crystals that melt as they polish. This gentle face wash exfoliates and cleanses all in one while smoothing the skin’s texture and maintaining its natural moisture.'),
(6, "Gimme Gimme More Charcoal Peppermint Scrub", 10.99, '6.jpg', 'Lift away dirt and dullness with a daily scrub made with real strawberries and smoothing sugar crystals that melt as they polish. This gentle face wash exfoliates and cleanses all in one while smoothing the skin’s texture and maintaining its natural moisture.'),
(7, "It’s All About That Face", 10.99, '7.jpg', "Antioxidant-packed, multifunction gel cleanser that's pH balanced, non-drying, and removes makeup with ease. Custom Superfoods Blend: Kale, spinach, green tea, alfalfa, vitamins C, E, K"),
(8, "Polyjuice Potion", 10.99, '8.jpg',  "Love Potion in a potion in a lotion. This pretty pink butter is hand whipped with sweet almond oil and shea butter to help smooth skin on your face. While natural fragrances react with your body chemistry to concoct a unique scent that sure to attract the right kind of attention."),
(9, "Youth to the People Black Head Clearing Scrub", 10.99, '9.jpg',  "NATURAL EXFOLIANTS: This face scrub is made with 100% natural exfoliants and salicylic acid to buff away dead skin and unclog pores for clear, radiant skin.");

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `UID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(150) NOT NULL DEFAULT '',
  `CONTACT` varchar(150) NOT NULL DEFAULT '',
  `ADDRESS` text,
  `CITY` varchar(45) NOT NULL DEFAULT '',
  `PINCODE` varchar(45) NOT NULL DEFAULT '',
  `EMAIL` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


-- --------------------------------------------------------

--
-- Table structure for table `administrators`
--

CREATE TABLE `administrators` (
  `adminID` int(11) NOT NULL,
  `emailAddress` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `administrators`
--

INSERT INTO `administrators` (`adminID`, `emailAddress`, `password`) VALUES
(1, 'admin@bubblebombbeauty.com', '$2a$10$PEnmRwrKKlFKJwop/IzsVeGARZvQhJp0jl.SRGkdrYVHcLn1GbVqq');

-- --------------------------------------------------------

-- Create a user named bubble_bomb
GRANT SELECT, INSERT, UPDATE, DELETE
ON *
TO bubble_bomb@localhost
IDENTIFIED BY 'bubblebomb';