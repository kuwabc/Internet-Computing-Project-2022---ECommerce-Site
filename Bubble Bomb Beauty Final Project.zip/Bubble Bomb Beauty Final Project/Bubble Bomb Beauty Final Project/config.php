<?php 
	$con=mysqli_connect("localhost","bubble_bomb","bubblebomb","bubblebombbeauty1");
	if(!$con){
		die("Database Connection Failed");
	}
?>